class enemyprojectile {
  
  float x;
  float y;
  float vx;
  float vy;
  float speed = 15;
  float angle;

  int time = 0;
  int destroyed = 0;
  
  
  //PImage proj;
  
  enemyprojectile(float x,float y,float angle) {
    
      this.x = x;
      this.y = y;
    
    
      //proj = loadImage("projectile.png");
     
       
      
      vx = cos(angle) * speed;
      vy = sin(angle) * speed;
    
  }
  
  
  void update() {
    x += vx;
    y += vy;
    
  }
  
  
 void display() {
   imageMode(CENTER);
   fill(100);
   ellipse(x,y,5,5);
 }
  
  
  
  void hitenemy() {


            destroyed = 1;
            
              
            

      
        }
     
  
}
  
