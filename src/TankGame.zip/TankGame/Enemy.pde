class Enemy {
  
  float x,y;
  float speed = 1;
  float tempx = 0;
  float tempy = 0;
  int randomX1 = round(random(width));
  int randomY2 = round(random(height));
  float angle = atan2(randomY2 - y, randomX1 - x);
  PImage tank;
  PImage turret;
  int hp = 1;
  
  Timer moveTimer;
  Timer shootTimer;
  
  Enemy() {
    x = int(random(width));
    y = int(random(height));
    tank = loadImage("tank.png");
    turret = loadImage("turret.png");
    
    moveTimer = new Timer(2000);
    moveTimer.start();
    shootTimer = new Timer(2000);
    shootTimer.start();
  }
  
  void display() {
    
    imageMode(CENTER);
    image(tank,x,y);
    
    float angle = atan2(playertank.y - y, playertank.x - x);
    
    pushMatrix();
    
    translate(x,y);
    
    rotate(angle);
    
    image(turret,0,0);
    
    popMatrix();
    
    if (x > width-10) {
      x = x - 1;
    }
    if (x < 10) {
      x = x + 1;
    }
    if (y < 10) {
      y = y + 1;
    }
    if (y > height-10) {
      y = y - 1;
    }
    
    
    
    
  }
  
  
  
  
  
  
  
  
  
  
  
  void collision() {
    
    
    
    hp--;
      
      
  }
  
  
  
  
  
  
  
  
  
  
  
  boolean isdestroyed() {
      
    
    
    return hp < 1;

  }
  
  
  
  
  void move() {

     
      
      x = x + cos(angle) * 1;
      y = y + sin(angle) * 1;
      
      if (moveTimer.isFinished()) {
      int random = int(random(1,3));
        
      if (random == 1) {randomX1 = round(random(width));
      randomY2 = round(random(height));}
      if (random == 2) {
        randomX1 = round(playertank.x);
        randomY2 = round(playertank.y);
        
      }
      
      
      angle = atan2(randomY2 - y, randomX1 - x);
      moveTimer.start();
    }
      
      
      
      

      

  
  }
  
  
  void shoot() {
  
   if (shootTimer.isFinished()) {
     println("success");
     angle = atan2(playertank.y - y, playertank.x - x);
     if (fail == false) {EnemyProjectile.add(new enemyprojectile(x,y,angle));}
     shootTimer.start();
   }
  }
  
  
}
