// alan huang gamedev1
  Tank playertank;
  Enemy[] enemies = new Enemy[5];
  winscreen winscreen1;
  failscreen failscreen1;
  ArrayList<projectile> Projectile = new ArrayList<projectile>();
  ArrayList<enemyprojectile> EnemyProjectile = new ArrayList<enemyprojectile>();
  
  boolean a = false;
  boolean d = false;
  boolean s = false;
  boolean w = false;
  boolean r = false;
  
  boolean win = false;
  boolean fail = false;
  


  void setup() {
    size(500,500);
    playertank = new Tank();
    winscreen1 = new winscreen();
    failscreen1 = new failscreen();
    
    for (int i = 0; i < enemies.length; i++) {
      enemies[i] = new Enemy();
    }
    
    
    
    
  }
  
  void draw() {
    background(155);
    playertank.display();
    playertank.move();
    playertank.shoot();
    winscreen1.display();
    failscreen1.display();
    
    for (int i = 0; i < enemies.length; i++) {
      if (enemies[i] != null) {
        enemies[i].display();
        enemies[i].move();
        enemies[i].shoot();
        if (dist(playertank.x,playertank.y,enemies[i].x,enemies[i].y) < 25) {
          fail = true;
        }
        if (fail == true) {
          enemies[i] = null;
          break;
        }
        
    if (enemies[i].isdestroyed()) {
        enemies[i] = null;
      }
    }
    }
      
     
     boolean enemiesleft = false;
     for (int v = 0; v < enemies.length; v++) {
       if (enemies[v] != null) {
         enemiesleft = true;
         break;
       }
     }
       if (enemiesleft == false) {
         win = true;
       }
       
    
    
    for (int i = Projectile.size() - 1; i >= 0; i--) {
      projectile p = Projectile.get(i);
      
      p.update();
      p.display();
      
        for (int d = 0; d < enemies.length; d++) {
          float distance = 25;
        if (enemies[d] != null) {distance = dist(enemies[d].x,enemies[d].y,p.x,p.y);}   
          if (distance < 25) {
            if (enemies[d] != null) {enemies[d].collision();}
            p.hitenemy();
          }
        }
        if (p.destroyed == 1) {
          Projectile.remove(i);
        }
      
      
    }
    
   
     for (int i = EnemyProjectile.size() - 1; i >= 0; i--) {
      enemyprojectile e = EnemyProjectile.get(i);
      
      e.update();
      e.display();
      
      float dist = dist(playertank.x,playertank.y,e.x,e.y);
      
      if (dist < 25) {
        fail = true;
      }
      
      
    
     }

    
    
    
    
    
  }
  
  void keyPressed() {
    if (key == 'A' || key == 'a') {
      a = true;
    }
    if (key == 'D' || key == 'd') {
      d = true;
    }
    if (key == 'W' || key == 'w') {
      w = true;
    }
    if (key == 'S' || key == 's') {
      s = true;
    }
  }
  
  void keyReleased() {
    if (key == 'A' || key == 'a') {
      a = false;
    }
    if (key == 'D' || key == 'd') {
      d = false;
    }
    if (key == 'W' || key == 'w') {
      w = false;
    }
    if (key == 'S' || key == 's') {
      s = false;
    }
  }
  
  void mousePressed() {
    if (mouseButton == LEFT) {
      r = true;
    }
  }
  void mouseReleased() {
    if (mouseButton == LEFT) {
      r = false;
    }
  }
  
  
  
