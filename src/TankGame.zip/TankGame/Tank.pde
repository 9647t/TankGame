class Tank {

  float x,y;
  float speed = 1;
  float tempx = 0;
  float tempy = 0;
  float hp = 3;
  PImage tank;
  PImage turret;
  
  Timer shootTimer;
  
  
  
  Tank() {
    x = int(random(width));
    y = int(random(height));
    tank = loadImage("tank.png");
    turret = loadImage("turret.png");
    
    shootTimer = new Timer(2000);
    shootTimer.start();
    
    
    
  }
  
  void display() {
    imageMode(CENTER);
    image(tank,x,y);
    
    float angle = atan2(mouseY - y, mouseX - x);
    
    pushMatrix();
    
    translate(x,y);
    
    rotate(angle);
    
    image(turret,0,0);
    
    popMatrix();
    
    
    
    
    
    
  
  }
  
  void move() {
    if (w) {
      tempy += -speed;
    }
    if (s) {
      tempy += speed;
    }
    if (a) {
      tempx += -speed;
    }
    if (d) {
      tempx += speed;
    }
    
    y += tempy;
    x += tempx;
    
    tempx = tempx * 0.7;
    tempy = tempy * 0.7;
    
  }
  
  
  void shoot() {
  
   if (shootTimer.isFinished() && (r)) {
     float angle = atan2(mouseY - y, mouseX - x);
     if (fail == false) {Projectile.add(new projectile(x,y,angle));}
     shootTimer.start();
   }
  
  
  }
 
   
  
  
}
