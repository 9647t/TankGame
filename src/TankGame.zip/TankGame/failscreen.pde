class failscreen {
  
  failscreen() {
  
  
  
  }
  
  
  void display() {
    if (fail == true) {
    background(200);
    textAlign(CENTER,CENTER);
    textSize(60);
    fill(100);
    text("DEFEAT.",width/2,height/2);
    textSize(20);
    text("run project to restart.", width/2, height/2+75);
    
    
    
    }
  
  }
  
  
  
  
}
