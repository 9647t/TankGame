class powerup {

  int x = 0;
  int y = 0;
  int poweruptype = int(random(1,4));
  int size;
  
  powerup() {
    
    x = int(random(width));
    y = int(random(height));
    
    
   }


  void display() {
    if (poweruptype == 1) {
      fill(250,120,10);
      rect(x,y,12,12);
      size = 20;
  }
    if (poweruptype ==2) {
    fill(150,120,10);
      rect(x,y,12,12);
      size = 12;
  }
    if (poweruptype == 3) {fill(50,120,10); rect(x,y,12,12); size = 12;}
  }





}
