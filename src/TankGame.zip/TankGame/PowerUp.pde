class powerup {






}
